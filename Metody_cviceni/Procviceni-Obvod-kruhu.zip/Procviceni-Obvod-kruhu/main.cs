using System;

class MainClass {
    //tuto metodu neměňte
    public static void Main (string[] args) {
        double polomer = 3;
        Console.WriteLine($"Obvod kruhu o poloměru {polomer} je {Obvod(polomer)}");
        polomer = 1.5;
        Console.WriteLine($"Obvod kruhu o poloměru {polomer} je {Obvod(polomer)}");
    }

    //Sem přijde váš kód
}