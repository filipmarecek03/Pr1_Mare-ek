using System;

class MainClass {
  public static void Main (string[] args) {
    //zde metodu zavolejte
  }

  //zde metodu deklarujte
}