using System;

class MainClass {
    //tuto metodu neupravujte
    public static void Main (string[] args) {
        Prijde("Karel");
    }

    public static void Prijde (string jmeno) {
        //sem přijde váš kód
    }
}