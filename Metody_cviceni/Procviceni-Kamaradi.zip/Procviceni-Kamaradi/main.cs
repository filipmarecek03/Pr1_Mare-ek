using System;

class MainClass {
    public static void Main (string[] args) {
        Kamaradi("Anička", "Karel");
    }

    //sem přijde váš kód
    public static
}