using System;

class MainClass {
    //tuto metodu neupravujte
    public static void Main (string[] args) {
        string text = Prijde("Karel"); //zde uložím návratovou hodnotu do proměnné
        Console.WriteLine(text);
    }

    public static string Prijde (string jmeno) {
        //sem přijde váš kód
    }
}