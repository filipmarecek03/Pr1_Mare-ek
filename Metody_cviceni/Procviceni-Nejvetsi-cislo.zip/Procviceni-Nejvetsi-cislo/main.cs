using System;

class MainClass {
    public static void Main (string[] args) {
        double cislo1 = 1.3;
        double cislo2 = 4.6;
        double cislo3 = -3.3;
        double maximum = //sem doplňte zavolání metody
        Console.WriteLine($"Největší ze zadaných čísel je {maximum}.");
    }

    //sem napište deklaraci metody
}